print("Here where you get to see my categorize value!")
print()
my_Mixed_Type_List = [45, 290578, 1.02, True, "My dog is on the bed.", "45"]
for item in my_Mixed_Type_List:
    print("{} is of the data type {}".format(item,type(item)))