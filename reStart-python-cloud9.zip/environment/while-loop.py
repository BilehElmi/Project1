print("Here where you get to see my while-loop at work!!")
print()
print()
print("Welcome To Guess the Number!")
print("the rules are simple. I will think of a number, and you will try to guess it.")
import random
number = random.randint(1,10)
note = "vatican city" 
isGuessRight = False

while isGuessRight != True:
    guess = input("Guess a number between 1 and 10: ")
    if int(guess) == number:
        print("You guessed {}. That is correct! You win!".format(guess))
        isGuessRight = True
    else:
        print("You guessed {}. Sorry, that isn’t it. Try again.".format(guess))
print()
print()

print("Next is guess the capital city of Vadican City.")
isGuessRight = False
while isGuessRight != True:
    
    guess = input ("What is the capital city of Vatican City? ")
    if str(guess) == note:
        print("You guessed {}. That is correct! very well done".format(note))
        isGuessRight = True
    else:
        print("You guessed {}. Sorry that isn't it. Try again!".format(note))
    
        