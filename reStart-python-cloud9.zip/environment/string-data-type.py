myString = "This is string point"
print (myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))
print()
first_string = "Water-"
second_string = "fall"
third_string = first_string + second_string
print (third_string)
print()
name = input("What is your name? ")
print(name)
color = input("What is your favourity color? ")
animal = input("What is your favourity animal? ")
print()
print("{}, you like a {} {}!".format(name,color,animal))
print()
next = input("Do you have one now? ")
then = input("Did you buy it? ")


answer = input("Enter yes or no: ").lower()
if answer == "yes":
    print("WOW!")
    print()
    
elif answer == "no":
    print("Hopeful soon then!")


