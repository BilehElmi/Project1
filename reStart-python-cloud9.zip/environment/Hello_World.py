
my_value =True 
print (my_value)
print()
print(str(my_value) + " is of the data type of " + str(str(my_value)))