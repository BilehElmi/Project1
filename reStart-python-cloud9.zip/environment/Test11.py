import getpass
import json
import os

users_file = "users json"
def load_users():
    if os.path.exists(users_file):
        with open(users_file, 'r') as f:
            return json.load(f)
    return {}

def save_users(users):
    with open(users_file, 'w') as f:
        json.dump(users, f)

def register():
    username = input("Enter a username: ")
    password = getpass.getpass("Enter a password: ")
    users[username] = password
    save_users(users)
    print("Registration successful!")

def login():
    username = input("Enter your username: ")
    password = getpass.getpass("Enter your password: ")
    if username in users and users[username] == password:
        print("Login successful!")
        return True
    else:
        print("Invalid username or password.")
        return False
users = load_users()

while True:
    print("\n1. Register")
    print("2. Login")
    print("3. Exit")
    choice = input("Enter your choice (1-3): ")

    if choice == '1':
        register()
    elif choice == '2':
        if login():
            break
    elif choice == '3':
        print("Goodbye!")
        break
    else:
        print("Invalid choice. Please try again.")