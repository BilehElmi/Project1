print("What is my fruit collections")
print()
my_fruit_list = ["Apple", "Banana", "Cherry"]
print(my_fruit_list)
print(type(my_fruit_list))
print(my_fruit_list[2])
print()
my_fruit_list[2] = "orange"
print(my_fruit_list)
print()

myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))
print()
print(myFinalAnswerTuple[1])

print(myFinalAnswerTuple[2])
print()

my_favority_fruit_dictionary = {
    "Abdul" : "apple",
    "Kadir" : "banana",
    "Bilal" : "pineapple"
}
print(my_favority_fruit_dictionary)

print(type(my_favority_fruit_dictionary))
print(my_favority_fruit_dictionary["Bilal"])
print(my_favority_fruit_dictionary["Abdul"])
print(my_favority_fruit_dictionary["Kadir"])